package com.example.projeto_tela

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
